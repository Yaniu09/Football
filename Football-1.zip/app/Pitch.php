<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Pitch extends Model
{
    //
}
